#Grafica de distribucion normal
Za <- as.numeric(readline("valor de alfa: "))
lim_inf=qnorm(Za);lim_inf
lim_inf <- as.numeric(readline("lim. inf.: "))
lim_sup <- as.numeric(readline("lim. sup.: "))
if (is.na(lim_inf))  {
  lim_inf <- -100
}
if (is.na(lim_sup))  {
  lim_sup <- 100
}
prob<- pnorm(lim_sup) - pnorm(lim_inf)
pnorm(lim_sup);pnorm(lim_inf);prob
round(prob, 2)
curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                   round(prob, 2)))
# Sombreamos el área
cord.x <- seq(lim_inf, lim_sup, 0.1);cord.x
cord.y <- dnorm(cord.x)
polygon(c(lim_inf, cord.x, lim_sup),c(0, cord.y ,0),col = "skyblue")
# Linea z calculado

abline(v=1.860163, col='red')
abline(v=1.612142, col='blue')


## Limite inferior
lim_sup<- qnorm(0.05)
curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                       round(lim_sup, 2)))
cord.x <- c(-3,seq(-3,lim_sup,0.01),lim_sup );
cord.y <- c(0,dnorm(seq(-3,lim_sup,0.01)),0)
polygon(c(-3, cord.x, lim_sup),c(0, cord.y ,0),col = "skyblue")

## Limite superior
lim_inf<- qnorm(0.95)
curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                       round(lim_inf, 2)))
cord.x <- c(lim_inf,seq(lim_inf,3,0.01),3);
cord.y <- c(0,dnorm(seq(lim_inf,3,0.01)),0)
polygon(cord.x, cord.y,col = "skyblue")

## Dos limites
lim_sup<- qnorm(0.05);lim_sup
lim_inf<- qnorm(0.95);lim_inf
curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                       round(lim_inf, 2)))
lim_inf;lim_sup
linf<-round(lim_inf,2);linf
lsup<-round(lim_sup,2);lsup
seq(linf,lsup, 0.01)

cord.x <- c(-1.64,seq(-1.64,1.64,0.01),1.64)
cord.y <- c(0,dnorm(seq(-1.64,1.64,0.01)),0)
polygon(cord.x, cord.y,col = "skyblue")

####
### Funcion para grafica de limites
Grafica_inferior <- function(alfa){
  lim_sup<- qnorm(alfa)
  curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                         round(lim_sup, 2)))
  cord.x <- c(-3,seq(-3,lim_sup,0.01),lim_sup );
  cord.y <- c(0,dnorm(seq(-3,lim_sup,0.01)),0)
  polygon(c(-3, cord.x, lim_sup),c(0, cord.y ,0),col = "skyblue")
}

Grafica_superior <- function(alfa){
  lim_inf<- qnorm(alfa)
  curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                         round(lim_inf, 2)))
  cord.x <- c(lim_inf,seq(lim_inf,3,0.01),3);
  cord.y <- c(0,dnorm(seq(lim_inf,3,0.01)),0)
  polygon(cord.x, cord.y,col = "skyblue")
}

Prueba_inferior <- function(alfa,valor){
  lim_sup<- qnorm(alfa)
  curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                         round(lim_sup, 2)))
  cord.x <- c(-3,seq(-3,lim_sup,0.01),lim_sup );
  cord.y <- c(0,dnorm(seq(-3,lim_sup,0.01)),0)
  polygon(c(-3, cord.x, lim_sup),c(0, cord.y ,0),col = "skyblue")
  if (valor>lim_sup){
    abline(v=valor, col='blue')
  }
  else{
    abline(v=valor,col='red')
  }
}

Prueba_superior <- function(alfa,valor){
  lim_inf<- qnorm(alfa)
  curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                         round(lim_inf, 2)))
  cord.x <- c(lim_inf,seq(lim_inf,3,0.01),3);
  cord.y <- c(0,dnorm(seq(lim_inf,3,0.01)),0)
  polygon(cord.x, cord.y,col = "skyblue")
  if (lim_inf>valor){
    abline(v=valor, col='blue')
  }
  else{
    abline(v=valor,col='red')
  }
}

