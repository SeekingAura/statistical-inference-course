dt(x, df, ncp, log = FALSE)
pt(q, df, ncp, lower.tail = TRUE, log.p = FALSE)
qt(p, df, ncp, lower.tail = TRUE, log.p = FALSE)
rt(n, df, ncp)


#valor t en 0.05 y 59 grados de libertad
num<-7-7.25;num
den<-1.052 / sqrt(60);den
ta=num/den;ta
qt(0.05, df=59,lower.tail = FALSE)

num<-37.4 - 40; num
den<-11.79/sqrt(25);den
tp<-num/den; tp



qt(0.025, df=24,lower.tail = FALSE)
pnorm(2.36)
dnorm(2.36)

qnorm(0.05)
#[1] -1.644854
120 - (1.64*(12/sqrt(36)))
#[1] 116.72
pnorm(2.36)
#[1] 0.9908625

#Si se rechaza Ho, la decisión será devolver el pedido al proveedor debido a 
#que la media del número de horas de vida útil es menor a 120 horas. 

#x_b =117 han encontrado en las pruebas que las baterias duran 
# en promedio 117 horas
x_b <- 117
z<- (x_b - 120) / (12 / sqrt(36)); z
#[1] -1.5
# zalfa= -1.64
#  -1,5 >= -1.64 se acepta la Ho y no devuelvo el pedido

x_b <- 121
z<- (x_b - 120) / (12 / sqrt(36)); z
#[1] 0.5
# zalfa= -1.64
#  0.5 >= -1.64 se acepta la Ho y no devuelvo el pedido

#x_b =112 han encontrado en las pruebas que las baterias duran 
# en promedio 121 horas
x_b <- 112
z<- (x_b - 120) / (12 / sqrt(36)); z
#[1] -4
dnorm(z)
# zalfa= -1.64
# -4 < -1.64 se rechaza Ho y se acepta Ha donde media < 120 horas, se devuelve el pedido

#Dado que el punto critico es 116.72 debo encontrar la probabilidad que se de un
#valor menor a este, para ello reescribo la ecuacion de Z de tal forma que el valor
#de referencia se al punto limite
miu <- 112
z<- (116.72 - miu) / (12 / sqrt(36)); z
beta<-pnorm(z) #acumulado
#[1] 0.9908625
# Valor beta=0.9908
potencia <- 1-beta;potencia
# potencia 1-beta 
#[1] 0.009137468



medias <- c(112,113,114,115,116,117,118)
z_medias <- (116.72 - medias)/(12/sqrt(36));z_medias
#[1]  2.36  1.36  0.86  0.36 -0.14 -0.64
prob_betas <- pnorm(z_medias);prob_betas
#[1] 0.9908625 0.9130850 0.8051055 0.6405764 0.4443300 0.2610863
pot_beta<- 1-prob_betas;pot_beta
#[1] 0.009137468 0.086914962 0.194894521 0.359423567 0.555670005 0.738913700

plot(medias, prob_betas, main = "Probabilidad de rechazar acertadamanre Ho",type = "o")

#Erro tipo II en dos colas
qnorm(0.03)
lmiz <- 5 + ((qnorm(0.03)*(0.25)) / sqrt(10));lmiz
lmde <- 5 + ((qnorm(0.03)*(0.25)) / sqrt(10));lmde

mediz <- c(4.9,4.85, 4.8, 4.75, 4.7, 4.65, 4.6); mediz
#4.90 4.85 4.80 4.75 4.70 4.65 4.60
z_mediz <- (4.851 - mediz)/(0.25/sqrt(10));z_mediz
#[1] -0.61980642  0.01264911  0.64510464  1.27756017  1.91001571  2.54247124
#[7]  3.17492677
prob_biz <- pnorm(z_mediz);prob_biz
#[1] 0.2676926 0.5050461 0.7405703 0.8992977 0.9719344 0.9944964 0.9992506
pot_biz<- 1-prob_biz;pot_biz
#[1] 0.7323073797 0.4949538695 0.2594296877 0.1007022752 0.0280655955 0.0055035830
#[7] 0.0007493716
plot(mediz, prob_biz, main = "Probabilidad de rechazar acertadamente Ho por izq",type = "o")

#Observacion del limite a izquierda
## Limite inferior
lim_inf<- qnorm(0.97)
curve(dnorm(x,0,1), xlim = c(-3, 3), las = 1, main = c("Probabilidad:", 
                                                       round(lim_inf, 2)))
cord.x <- c(lim_inf,seq(lim_inf,3,0.01),3);
cord.y <- c(0,dnorm(seq(lim_inf,3,0.01)),0)
polygon(cord.x, cord.y,col = "skyblue")

#Calculo valores cercanos al limite
miug<-4.8
z_guadua <- (5 - miug)/(0.25/sqrt(10));z_guadua
abline(v=z_guadua)


##########
#limte izquierda
medde <- c(5.15, 5.2, 5.25, 5.3, 5.35, 5.4); medde
#[1] 5.15 5.20 5.25 5.30 5.35 5.40
z_medde <- (5.148 - medde)/(0.25/sqrt(10));z_medde
#[1] -0.02529822 -0.65775375 -1.29020929 -1.92266482 -2.55512035 -3.18757588
#ATENCION DEBE SER LIMITE SUPERIOR
prob_bde <- pnorm(1-z_medde);prob_bde
#[1] 0.8473888 0.9513164 0.9889954 0.9982648 0.9998111 0.9999859
pot_bde<- 1-prob_bde ;pot_bde
#[1] 1.526112e-01 4.868359e-02 1.100459e-02 1.735249e-03 1.889031e-04 1.409749e-05
plot(medde, prob_bde, main = "Probabilidad de rechazar acertadamente Ho por der",type = "o")
