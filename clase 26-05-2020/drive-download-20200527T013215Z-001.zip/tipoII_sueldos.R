#n_h:40, desv_h:102  miu_h:725  miu_m:670
#Ha Mujeres ganan menos que los hombres  miu_m  <  725
#Ho Mujeres ganan igual o mas que los hombres  miu_m >= 725
# alfa 95%, 1-0.05=0.05  Za=Z(0.05)=1.64

#ERROR; debe ser 1-0.05
Za<-qnorm(1-0.05);Za
#[1] 1.644854

#Condicion aceptacion o rechazo
# z >= 1.64 Se RECHAZA Ho, acepta Ha mujeres ganan menos que los hombres
# z < 1.64 Se ACEPTA Ho

z<- (725 - 670) / (102 / sqrt(40)); z
#[1] 3.410299
# Se cumple z:3.41 > 1.64 se rechaza Ho, acepta mujeres ganan menos


# miu_h - miu_h / (desv_h / raiz(n_h)) = z
miu_limite <- 725 - (1.64*(102/sqrt(40))); miu_limite
#[1] 698.5507


miu_m <- c(695, 696, 697, 698, 699, 700)
# z= miu_h - miu_h / (desv_h / raiz(n_h)) 
z_g<- (725 - miu_m) / (102 / sqrt(40));
z_g
#[1] 1.860163 1.798158 1.736152 1.674147 1.612142 1.550136
#limite za=1.64
# Mayores a Za:  1.860163 1.798158 1.736152 1.674147
#corresponden a 695, 696, 697, 698, estos valores rechazan Ho
# y aceptan la Ha mujeres ganan menos
# Menores a Za: 1.612142 1.550136
# corresponden a 699, 700 NO rechazan la Ho Mujeres ganan igual o mas que los hombres

## zb= 698.55 - miu_h / (desv_h / raiz(n_h)) 
#miu_m <- c(695, 696, 697, 698, 699, 700)
zb <- (698.55 - miu_m) / (102 / sqrt(40)) ;zb
beta<-pnorm(zb);beta #acumulado
#[1] 0.5871109 0.5628165 0.5382828 0.5136025 0.4888700 0.4641802
# potencia
potencia <- 1-beta;potencia
